import React from "react";

const Footer = () => {
  return <footer className="footer">© 2025 Precious Aubrey M. Costales</footer>;
};

export default Footer;
