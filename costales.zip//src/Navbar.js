import React from "react";
import raibyLogo from "./assets/raiby.png";
import "./styles.css";

const Navbar = ({ setActivePage }) => {
  return (
    <nav className="navbar">
      <div className="nav-links">
        <button onClick={() => setActivePage("home")}>Home</button>
        <button onClick={() => setActivePage("about")}>About</button>
        <button onClick={() => setActivePage("contact")}>Contact</button>
      </div>
      <a href="#" className="navbar-brand">
        <img src={raibyLogo} alt="Raiby Logo" className="logo" />
      </a>
    </nav>
  );
};

export default Navbar;
