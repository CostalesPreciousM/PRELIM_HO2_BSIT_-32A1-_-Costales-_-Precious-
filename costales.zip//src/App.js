import React, { useState } from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";
import "./styles.css";

const Pages = () => {
  const [activePage, setActivePage] = useState("home");

  const showHobbies = () => {
    alert(
      "Hobbies: Singing, learning about technology, and exploring new skills."
    );
  };

  return (
    <div className="container">
      <Navbar setActivePage={setActivePage} />

      <div className="content-box">
        {activePage === "home" && (
          <div className="content">
            <p>
              <strong>Name:</strong> Precious Aubrey M. Costales
            </p>
            <p>
              <strong>Section:</strong> BSIT 32A1
            </p>
            <p>
              <strong>Academic Interests:</strong> Passionate about gaining more
              knowledge in computing.
            </p>
            <button className="btn-primary" onClick={showHobbies}>
              Show My Hobbies
            </button>
          </div>
        )}

        {activePage === "about" && (
          <div className="content">
            <h2>About Myself</h2>
            <p>
              <strong>Education:</strong> 3rd Year College | NCII Certified in
              Computer Systems Servicing (CSS)
            </p>
            <p>
              <strong>School Activities:</strong> Member of a singing choir
              (currently inactive due to academic focus).
            </p>
            <p>
              <strong>Skills:</strong> Strong communication skills,
              problem-solving, teamwork.
            </p>
          </div>
        )}

        {activePage === "contact" && (
          <div className="content">
            <h2>Contact Info</h2>
            <p>
              <strong>Name:</strong> Precious Aubrey M. Costales
            </p>
            <p>
              <strong>Email:</strong>{" "}
              <a href="mailto:itsgucciprecious@gmail.com">
                itsgucciprecious@gmail.com
              </a>
            </p>
            <p>
              <strong>Subject:</strong> IT ELECTIVE 3
            </p>
            <p>
              <strong>Message:</strong> Have a wonderful day!
            </p>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
};

export default Pages;
